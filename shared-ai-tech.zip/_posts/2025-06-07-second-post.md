---
layout: post
title: "5 Cool VS Code Extensions for Devs"
---

Here are 5 extensions every developer should try in Visual Studio Code...