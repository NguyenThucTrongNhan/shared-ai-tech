---
layout: post
title: "How to Build a GitHub Pages Blog"
---

Welcome to our first tech blog post! Today we learn how to use GitHub Pages with Jekyll...